{
    "name": "idk",
    "world": "Archway",
    "mode": "solo",
    "teams": {
        "Yellow": {
            "color": "e"
        },
        "Green": {
            "color": "a"
        },
        "Red": {
            "color": "c"
        },
        "Blue": {
            "color": "9"
        }
    },
    "generetors": [],
    "hub": null,
    "generators": []
}