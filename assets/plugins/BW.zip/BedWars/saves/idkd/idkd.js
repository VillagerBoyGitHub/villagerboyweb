{
    "name": "idkd",
    "world": "Ashore",
    "mode": "solo",
    "teams": {
        "Green": {
            "color": "a"
        },
        "Red": {
            "color": "c"
        },
        "Yellow": {
            "color": "e"
        },
        "Blue": {
            "color": "9"
        }
    },
    "generetors": [],
    "hub": null,
    "generators": []
}